
<?php 
    $id_paket =$_POST['idPaket'];
    $id_file =$_POST['idFile'];
    $user = $_SESSION['namalengkap'];

	// check the file is uploaded or not

		if (!is_dir('dirname(__FILE__)./upload/'.$user)) {
            mkdir('dirname(__FILE__)./upload/'.$user, 0777, TRUE);
        }
	
	
	if (is_uploaded_file($_FILES['attachment']['tmp_name'])) {   
	

		// Determine the file location
		$basename = basename($_FILES['attachment']['name']);
		$file = $_FILES['attachment']['name'];
		
		$extension  = ".".pathinfo($file, PATHINFO_EXTENSION);
		$namabaru = $id_file.'-'.$id_paket.$extension;
		
		$newname = dirname(__FILE__) . '/upload/'.$user.'/' .$namabaru;
	    
		if($_FILES['attachment']['size'] > 2097152) {
			$errors[]='File size must be excately 2 MB';
		}
		
		// Check Allowed File Types
		$file_ext=strtolower(end(explode('.',$_FILES['attachment']['name'])));
		$extensions= array("pdf","doc","docx");
		if(in_array($file_ext,$extensions)=== false){
			$errors[]="File extension not allowed, please choose a PDF, DOC, DOCX file.";
		}
		
		if(empty($errors)==true){
			// Move the file from temporary location to determined location
			if (!(move_uploaded_file($_FILES['attachment']['tmp_name'], $newname))) {
				echo "<p>ERROR:  A problem occurred during file upload!</p>\n";
			} else {
				echo "<p>The file has been saved as: {$newname}</p>\n";
				echo "<p>The file has been saved as: {$namabaru}</p>\n";
				echo "<p>The file has been saved as: {$user}</p>\n";
			}
		}
		else{
			print_r($errors);
		}
  }
 ?>