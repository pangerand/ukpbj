<?php
if (!isset($_SESSION['satker'])) {
   header('location: ../');
}

if (isset($_GET['action'])) {

   switch ($_GET['action']) {
      case 'tambah':
         include('./paket/add.php');
         break;

      case 'edit':
         include('./kegiatan/edit_kegiatan.php');
         break;
     case 'datail':
         include('./paket/detail.php');
         break;
         
    case 'upload':
         include('./paket/upload.php');
         break;
    case 'prosesupload':
         include('./paket/prosesupload.php');
         break;
    case 'alfa':
         include('./kegiatan/alfa_pdf.php');
         break;
    case 'absendiv':
         include('./kegiatan/absen_divisi.php');
         break;
         case 'tdkabsen':
         include('./kegiatan/tidak_absen_divisi.php');
         break;
    case 'qrcode':
         include('./kegiatan/buatQRCode_kegiatan.php');
         break;
         
      case 'hapus':

         if (isset($_GET['id'])) {

            $nis   = strip_tags(mysqli_real_escape_string($con, $_GET['id']));

            $sql   = $con->prepare("DELETE FROM t_paket WHERE id_paket = ?");
            $sql->bind_param('s', $nis);
            $sql->execute();

            header('location: ?page=paket');

         } else {

            header('location: ./');

         }

         break;
      default:
         include('./paket/list.php');
         break;
   }

} else {

   include('./paket/list.php');

}
?>
